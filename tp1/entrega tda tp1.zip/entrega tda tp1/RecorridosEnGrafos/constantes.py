#!/usr/bin/python
# -*- coding: utf-8 -*-
POSITIVE_INFINITY = float("inf")